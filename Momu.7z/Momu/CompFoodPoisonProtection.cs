﻿using System;
using Verse;

namespace Momu
{
	// Token: 0x02000007 RID: 7
	public class CompFoodPoisonProtection : ThingComp
	{
		// Token: 0x17000002 RID: 2
		// (get) Token: 0x06000014 RID: 20 RVA: 0x00002731 File Offset: 0x00000931
		public CompProperties_FoodPoisonProtection Props
		{
			get
			{
				return (CompProperties_FoodPoisonProtection)this.props;
			}
		}
	}
}
