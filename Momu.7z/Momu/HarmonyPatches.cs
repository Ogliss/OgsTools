﻿using System;
using System.Linq;
using HarmonyLib;
using RimWorld;
using Verse;

namespace Momu
{
	// Token: 0x02000008 RID: 8
	[StaticConstructorOnStartup]
	public static class HarmonyPatches
	{
		// Token: 0x06000016 RID: 22 RVA: 0x00002740 File Offset: 0x00000940
		static HarmonyPatches()
		{
			Harmony harmonyInstance = new Harmony("rimworld.ogliss.momu.harmony");
			Type typeFromHandle = typeof(HarmonyPatches);
			harmonyInstance.Patch(AccessTools.Method(typeof(FoodUtility), "AddFoodPoisoningHediff", null, null), new HarmonyMethod(typeFromHandle, "Pre_AddFoodPoisoningHediff_CompCheck", null), null, null);
			harmonyInstance.Patch(AccessTools.Method(typeof(ApparelUtility), "HasPartsToWear", new Type[]
			{
				typeof(Pawn),
				typeof(ThingDef)
			}, null), null, new HarmonyMethod(typeFromHandle, "Post_HasPartsToWear_BodyTypeRestriction", null), null);
			harmonyInstance.Patch(AccessTools.Method(typeof(FoodUtility), "WillEat", new Type[]
			{
				typeof(Pawn),
				typeof(Thing),
				typeof(Pawn),
				typeof(bool)
			}, null), null, new HarmonyMethod(typeFromHandle, "Post_WillEat_IngredientRestriction", null), null);
		}

		// Token: 0x06000017 RID: 23 RVA: 0x00002830 File Offset: 0x00000A30
		public static void Post_WillEat_IngredientRestriction(Pawn p, Thing food, Pawn getter, ref bool __result)
		{
			if ((Find.Selector.SingleSelectedThing == p || Find.Selector.SingleSelectedThing == getter) && Prefs.DevMode)
			{
				bool godMode = DebugSettings.godMode;
			}
			bool flag = p != null;
			if (flag)
			{
				bool flag2 = getter != null;
				if (flag2)
				{
					bool flag3 = food != null;
					if (flag3)
					{
						bool flag4 = p.def.defName.Contains("Momu");
						if (flag4)
						{
							bool flag5 = food.def == ThingDefOf.MealSimple;
							if (flag5)
							{
								CompIngredients compIngredients = ThingCompUtility.TryGetComp<CompIngredients>(food);
								bool flag6 = compIngredients != null;
								if (flag6)
								{
									bool flag7 = compIngredients.ingredients.All((ThingDef ingred) => ingred.ingestible.foodType == (FoodTypeFlags)1 || ingred.ingestible.foodType == (FoodTypeFlags)3857 || ingred.ingestible.foodType == (FoodTypeFlags)3921 || ingred.ingestible.foodType == (FoodTypeFlags)16 || ingred.ingestible.foodType == (FoodTypeFlags)64);
									if (flag7)
									{
										__result = true;
									}
									else
									{
										__result = false;
									}
								}
							}
						}
					}
				}
			}
		}

		// Token: 0x06000018 RID: 24 RVA: 0x00002914 File Offset: 0x00000B14
		public static void Post_HasPartsToWear_BodyTypeRestriction(Pawn p, ThingDef apparel, ref bool __result)
		{
			bool flag = apparel.HasComp(typeof(CompApparelBodyRestriction));
			if (flag)
			{
				CompProperties_ApparelBodyRestriction compProperties = apparel.GetCompProperties<CompProperties_ApparelBodyRestriction>();
				bool flag2 = compProperties != null;
				if (flag2)
				{
					bool flag3 = !compProperties.AllowedBodyTypes.Contains(p.story.bodyType);
					if (flag3)
					{
						__result = false;
					}
				}
			}
		}

		// Token: 0x06000019 RID: 25 RVA: 0x00002970 File Offset: 0x00000B70
		public static bool Pre_AddFoodPoisoningHediff_CompCheck(Pawn pawn, Thing ingestible, FoodPoisonCause cause)
		{
			CompFoodPoisonProtection compFoodPoisonProtection = ThingCompUtility.TryGetComp<CompFoodPoisonProtection>(pawn);
			bool flag = compFoodPoisonProtection != null;
			if (flag)
			{
				bool flag2 = !compFoodPoisonProtection.Props.Poisonable;
				if (flag2)
				{
					return false;
				}
				bool flag3 = !GenList.NullOrEmpty<FoodTypeFlags>(compFoodPoisonProtection.Props.FoodTypeFlags);
				if (flag3)
				{
					foreach (FoodTypeFlags foodTypeFlags in compFoodPoisonProtection.Props.FoodTypeFlags)
					{
						bool flag4 = foodTypeFlags == ingestible.def.ingestible.foodType;
						if (flag4)
						{
							return false;
						}
					}
				}
				bool flag5 = !GenList.NullOrEmpty<FoodPoisonCause>(compFoodPoisonProtection.Props.FoodPoisonCause);
				if (flag5)
				{
					foreach (FoodPoisonCause foodPoisonCause in compFoodPoisonProtection.Props.FoodPoisonCause)
					{
						bool flag6 = foodPoisonCause == cause;
						if (flag6)
						{
							return false;
						}
					}
				}
			}
			return true;
		}
	}
}
