﻿using System;
using Verse;

namespace Momu
{
	// Token: 0x02000004 RID: 4
	public class CompApparelBodyRestriction : ThingComp
	{
		// Token: 0x17000001 RID: 1
		// (get) Token: 0x0600000F RID: 15 RVA: 0x00002528 File Offset: 0x00000728
		public CompProperties_ApparelBodyRestriction Props
		{
			get
			{
				return (CompProperties_ApparelBodyRestriction)this.props;
			}
		}
	}
}
