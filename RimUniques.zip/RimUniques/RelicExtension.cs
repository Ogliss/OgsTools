﻿using System;
using System.Text;
using System.Threading.Tasks;
using Verse;

namespace RimUniques
{
    // AdeptusMechanicus.RelicExtension
    public class RelicExtension : DefModExtension
    {
        public RelicTracked relicProps = new RelicTracked();
    }

}